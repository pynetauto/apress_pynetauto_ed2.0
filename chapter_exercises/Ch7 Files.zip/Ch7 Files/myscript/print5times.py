#!/usr/bin/python3
x = 'Python Network Automation\n'
print(x*5)
