import os

for i in range(1, 101):        # Create 100 directories
    d_name = f'p{i}'
    os.makedirs(d_name, exist_ok=True)

for i in range(1, 101):        # Create a file in each directory
    d_name = f'p{i}'
    f_name = f'x{i}.txt'
    f_path = os.path.join(d_name, f_name)
    with open(f_path, 'w'):
        pass
