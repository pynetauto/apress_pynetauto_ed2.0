#!/bin/bash

# Create 100 directories
for i in {1..100}; do
    mkdir "d$i"
done

# Create a file in each directory with a corresponding name
for i in {1..100}; do
    touch "d$i/f$i.txt"
done
